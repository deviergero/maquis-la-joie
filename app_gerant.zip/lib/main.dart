import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyDGL3A-jZLKyef45JvcTAWnJKxY2HoAZq0",
      authDomain: "maqui-1946e.firebaseapp.com",
      projectId: "maqui-1946e",
      storageBucket: "maqui-1946e.firebasestorage.app",
      messagingSenderId: "35564360394",
      appId: "1:35564360394:web:ab77dcdd1daa44219e1a33",
      measurementId: "G-TQBRR9JC28",
    ),
  );
  runApp(const MaquisProApp());
}

class MaquisProApp extends StatelessWidget {
  const MaquisProApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Maquis La Joie Pro',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0B1120),
        cardColor: const Color(0xFF111827),
        primaryColor: const Color(0xFFF59E0B),
        colorScheme: const ColorScheme.dark(
            primary: Color(0xFFF59E0B),
            secondary: Color(0xFF1E40AF),
            surface: Color(0xFF111827)),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF1F2937),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide.none),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFF59E0B),
            foregroundColor: Colors.black,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            textStyle: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
      ),
      home: const PageDeConnexion(),
    );
  }
}

// ==========================================
// 1. CONNEXION
// ==========================================
class PageDeConnexion extends StatefulWidget {
  const PageDeConnexion({super.key});
  @override
  State<PageDeConnexion> createState() => _PageDeConnexionState();
}

class _PageDeConnexionState extends State<PageDeConnexion> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;
  String _errorMessage = "";

  void _authentifier() async {
    if (_emailController.text.trim().isEmpty ||
        _passwordController.text.trim().isEmpty) return;
    setState(() {
      _isLoading = true;
      _errorMessage = "";
    });
    String email = _emailController.text.trim().toLowerCase();
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email, password: _passwordController.text.trim());
      if (email == "retrait412@gmail.com") {
        if (mounted)
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => const TableauDeBordGerantPage()));
      } else {
        if (mounted)
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => const ChoixNomServeurPage()));
      }
    } catch (e) {
      if (mounted)
        setState(() {
          _isLoading = false;
          _errorMessage = "Identifiants incorrects.";
        });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            gradient: RadialGradient(
                colors: [Color(0xFF1E293B), Color(0xFF0B1120)],
                center: Alignment.topLeft,
                radius: 1.5)),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(35),
            child: Column(
              children: [
                const Icon(Icons.local_bar, size: 65, color: Color(0xFFF59E0B)),
                const SizedBox(height: 20),
                const Text("MAQUIS LA JOIE",
                    style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        fontSize: 26,
                        letterSpacing: 1.5)),
                const Text("SYSTÈME PRO",
                    style: TextStyle(
                        color: Color(0xFFF59E0B),
                        letterSpacing: 5,
                        fontWeight: FontWeight.bold,
                        fontSize: 12)),
                const SizedBox(height: 50),
                TextField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.mail_outline),
                        hintText: "Email d'accès")),
                const SizedBox(height: 18),
                TextField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.lock_outline),
                        hintText: "Mot de passe")),
                if (_errorMessage.isNotEmpty)
                  Padding(
                      padding: const EdgeInsets.only(top: 20),
                      child: Text(_errorMessage,
                          style: const TextStyle(
                              color: Color(0xFFEF4444),
                              fontWeight: FontWeight.bold))),
                const SizedBox(height: 40),
                SizedBox(
                    width: double.infinity,
                    height: 60,
                    child: ElevatedButton(
                        onPressed: _isLoading ? null : _authentifier,
                        child: _isLoading
                            ? const CircularProgressIndicator(
                                color: Colors.black)
                            : const Text("OUVRIR LA SESSION"))),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ChoixNomServeurPage extends StatefulWidget {
  const ChoixNomServeurPage({super.key});
  @override
  State<ChoixNomServeurPage> createState() => _ChoixNomServeurPageState();
}

class _ChoixNomServeurPageState extends State<ChoixNomServeurPage> {
  final TextEditingController _nomController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(backgroundColor: Colors.transparent, elevation: 0, actions: [
        IconButton(
            icon: const Icon(Icons.logout, color: Color(0xFFEF4444)),
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              if (context.mounted)
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const PageDeConnexion()));
            })
      ]),
      body: Center(
          child: Padding(
              padding: const EdgeInsets.all(35),
              child: Card(
                  color: const Color(0xFF111827),
                  child: Padding(
                      padding: const EdgeInsets.all(30),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.badge_outlined,
                            size: 85, color: Color(0xFFF59E0B)),
                        const SizedBox(height: 25),
                        const Text("Identifiez-vous",
                            style: TextStyle(
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                                fontSize: 18)),
                        const SizedBox(height: 35),
                        TextField(
                            controller: _nomController,
                            textCapitalization: TextCapitalization.characters,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w900,
                                color: Colors.white),
                            decoration: const InputDecoration(
                                hintText: "VOTRE NOM (ex: JEAN)")),
                        const SizedBox(height: 35),
                        SizedBox(
                            width: double.infinity,
                            height: 60,
                            child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF10B981)),
                                onPressed: () {
                                  if (_nomController.text.trim().isNotEmpty) {
                                    Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                MainNavigation(
                                                    nomServeur: _nomController
                                                        .text
                                                        .trim()
                                                        .toUpperCase())));
                                  }
                                },
                                child: const Text("PRENDRE MON SERVICE",
                                    style: TextStyle(color: Colors.white))))
                      ]))))),
    );
  }
}

// ==========================================
// 2. LE TABLEAU DE BORD GÉRANT
// ==========================================
class TableauDeBordGerantPage extends StatelessWidget {
  const TableauDeBordGerantPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("DIRECTION",
              style: TextStyle(fontWeight: FontWeight.w800)),
          backgroundColor: const Color(0xFF111827),
          centerTitle: true,
          elevation: 0,
          actions: [
            IconButton(
                icon: const Icon(Icons.logout, color: Color(0xFFEF4444)),
                onPressed: () async {
                  await FirebaseAuth.instance.signOut();
                  if (context.mounted)
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const PageDeConnexion()));
                })
          ],
          bottom: const TabBar(
              indicatorColor: Color(0xFFF59E0B),
              labelColor: Color(0xFFF59E0B),
              unselectedLabelColor: Colors.grey,
              tabs: [
                Tab(icon: Icon(Icons.dashboard), text: "VUE GLOBALE"),
                Tab(icon: Icon(Icons.folder_shared), text: "DOSSIERS")
              ]),
        ),
        body: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('ventes_directes')
              .orderBy('timestamp', descending: true)
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting)
              return const Center(child: CircularProgressIndicator());
            if (!snapshot.hasData || snapshot.data!.docs.isEmpty)
              return const Center(
                  child: Text("Aucune donnée enregistrée.",
                      style: TextStyle(color: Colors.grey)));

            final docsVentes = snapshot.data!.docs;
            int grandTotal = 0;
            Map<String, int> perfServeurs = {};
            Set<String> listeNomsServeurs = {};
            for (var d in docsVentes) {
              int recette = (d['total'] as int? ?? 0);
              String nom = d['serveur'].toString().toUpperCase();
              grandTotal += recette;
              perfServeurs[nom] = (perfServeurs[nom] ?? 0) + recette;
              listeNomsServeurs.add(nom);
            }
            var serveursTries = perfServeurs.entries.toList()
              ..sort((a, b) => b.value.compareTo(a.value));

            return TabBarView(
              children: [
                CustomScrollView(
                  slivers: [
                    SliverToBoxAdapter(
                        child: Container(
                            width: double.infinity,
                            margin: const EdgeInsets.all(20),
                            padding: const EdgeInsets.all(30),
                            decoration: BoxDecoration(
                                gradient: const LinearGradient(colors: [
                                  Color(0xFF1E40AF),
                                  Color(0xFF0B1120)
                                ]),
                                borderRadius: BorderRadius.circular(25),
                                border:
                                    Border.all(color: const Color(0x80F59E0B))),
                            child: Column(children: [
                              const Text("CHIFFRE D'AFFAIRES GLOBAL EN DIRECT",
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 15),
                              Text("$grandTotal FCFA",
                                  style: const TextStyle(
                                      fontSize: 40,
                                      fontWeight: FontWeight.w900,
                                      color: Color(0xFFFBBF24)))
                            ]))),
                    const SliverToBoxAdapter(
                        child: Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 25, vertical: 10),
                            child: Text("CLASSEMENT DU JOUR",
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                    fontSize: 16)))),
                    SliverList(
                        delegate: SliverChildBuilderDelegate((context, index) {
                      return Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 5),
                          child: Card(
                              color: const Color(0xFF111827),
                              child: ListTile(
                                  leading: CircleAvatar(
                                      backgroundColor: index == 0
                                          ? const Color(0xFFF59E0B)
                                          : const Color(0xFF1F2937),
                                      child: Text("${index + 1}",
                                          style: TextStyle(
                                              color: index == 0
                                                  ? Colors.black
                                                  : Colors.white,
                                              fontWeight: FontWeight.bold))),
                                  title: Text(serveursTries[index].key,
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18)),
                                  trailing: Text(
                                      "${serveursTries[index].value} F",
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w900,
                                          color: Color(0xFF10B981),
                                          fontSize: 18)))));
                    }, childCount: serveursTries.length)),
                  ],
                ),
                ListView.builder(
                  padding: const EdgeInsets.all(20),
                  itemCount: listeNomsServeurs.length,
                  itemBuilder: (context, index) {
                    String nom = listeNomsServeurs.elementAt(index);
                    return Card(
                        color: const Color(0xFF111827),
                        margin: const EdgeInsets.only(bottom: 15),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)),
                        child: ListTile(
                            contentPadding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 10),
                            leading: const Icon(Icons.folder_shared,
                                color: Color(0xFFF59E0B), size: 35),
                            title: Text("Dossier de $nom",
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18,
                                    color: Colors.white)),
                            subtitle: const Text("Voir ses ventes et clôtures"),
                            trailing: const Icon(Icons.arrow_forward_ios,
                                color: Colors.grey),
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          FicheServeurPage(nomServeur: nom)));
                            }));
                  },
                )
              ],
            );
          },
        ),
      ),
    );
  }
}

class FicheServeurPage extends StatelessWidget {
  final String nomServeur;
  const FicheServeurPage({required this.nomServeur, super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
            title: Text("ACTIVITÉ : $nomServeur",
                style: const TextStyle(fontWeight: FontWeight.w800)),
            backgroundColor: const Color(0xFF111827),
            bottom: const TabBar(
                indicatorColor: Color(0xFFF59E0B),
                labelColor: Color(0xFFF59E0B),
                unselectedLabelColor: Colors.grey,
                tabs: [
                  Tab(text: "VENTES (DÉTAIL)"),
                  Tab(text: "CLÔTURES (BILANS)")
                ])),
        body: TabBarView(
          children: [
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('ventes_directes')
                  .orderBy('timestamp', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData)
                  return const Center(child: CircularProgressIndicator());
                var sesVentes = snapshot.data!.docs
                    .where((doc) =>
                        doc['serveur'].toString().toUpperCase() == nomServeur)
                    .toList();
                if (sesVentes.isEmpty)
                  return const Center(child: Text("Aucune vente détaillée."));
                return ListView.builder(
                    padding: const EdgeInsets.all(15),
                    itemCount: sesVentes.length,
                    itemBuilder: (context, index) {
                      var v = sesVentes[index];
                      return Card(
                          color: const Color(0xFF111827),
                          child: ListTile(
                              leading: const Icon(Icons.receipt,
                                  color: Color(0xFF10B981)),
                              title: Text("${v['client']} (${v['table']})",
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold)),
                              subtitle: Text("Encaissé le : ${v['date']}"),
                              trailing: Text("+ ${v['total']} F",
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: Color(0xFF10B981),
                                      fontSize: 16))));
                    });
              },
            ),
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('bilans_caisse')
                  .orderBy('timestamp_internet', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData)
                  return const Center(child: CircularProgressIndicator());
                var sesBilans = snapshot.data!.docs
                    .where((doc) =>
                        doc['serveur'].toString().toUpperCase() == nomServeur)
                    .toList();
                if (sesBilans.isEmpty)
                  return const Center(
                      child: Text("Aucune caisse fermée pour le moment."));
                return ListView.builder(
                    padding: const EdgeInsets.all(15),
                    itemCount: sesBilans.length,
                    itemBuilder: (context, index) {
                      var b = sesBilans[index];
                      return Card(
                          color: const Color(0xFF1F2937),
                          child: ListTile(
                              leading: const Icon(Icons.lock,
                                  color: Color(0xFFF59E0B)),
                              title: Text(
                                  "Bilan déposé le : ${b['date_cloture']}",
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14)),
                              subtitle: Text(
                                  "Total des commandes : ${b['commandes_servies']}"),
                              trailing: Text("${b['recette_totale']} F",
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: Color(0xFFFBBF24),
                                      fontSize: 18))));
                    });
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 3. ESPACE CAISSE SERVEUR
// ==========================================
class MainNavigation extends StatefulWidget {
  final String nomServeur;
  const MainNavigation({required this.nomServeur, super.key});
  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _selectedIndex = 0;
  int totalEncaisseSession = 0;
  int commandesTermineesSession = 0;
  bool finDeServiceSignalee = false;
  String _obtenirDateExacte() {
    final now = DateTime.now();
    return "${now.day.toString().padLeft(2, '0')}/${now.month.toString().padLeft(2, '0')}/${now.year} à ${now.hour}h${now.minute.toString().padLeft(2, '0')}";
  }

  List<Map<String, dynamic>> commandesAcceptees = [];
  List<Map<String, dynamic>> monnaieEnAttente = [];
  List<Map<String, dynamic>> historiqueVentes = [];

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      CommandesEnCoursPage(
          disabled: finDeServiceSignalee,
          nomServeur: widget.nomServeur,
          onAccept: (cmd) => setState(() {
                commandesAcceptees.add(cmd);
              })),
      CaisseIntelligentePage(
          commandesPayer: commandesAcceptees,
          commandesMonnaie: monnaieEnAttente,
          disabled: finDeServiceSignalee,
          nomServeur: widget.nomServeur,
          onComplete: (cmd) async {
            setState(() {
              commandesAcceptees.remove(cmd);
              cmd['date_fin'] = _obtenirDateExacte();
              historiqueVentes.add(cmd);
              totalEncaisseSession += cmd['total'] as int;
              commandesTermineesSession++;
            });
            await FirebaseFirestore.instance.collection('ventes_directes').add({
              'serveur': widget.nomServeur,
              'client': cmd['client'],
              'table': cmd['table'],
              'total': cmd['total'],
              'date': _obtenirDateExacte(),
              'timestamp': FieldValue.serverTimestamp()
            });
          },
          onAttenteMonnaie: (cmd) => setState(() {
                commandesAcceptees.remove(cmd);
                monnaieEnAttente.add(cmd);
              }),
          onRendreMonnaie: (cmd) async {
            setState(() {
              monnaieEnAttente.remove(cmd);
              cmd['date_fin'] = _obtenirDateExacte();
              historiqueVentes.add(cmd);
              totalEncaisseSession += cmd['total'] as int;
              commandesTermineesSession++;
            });
            await FirebaseFirestore.instance.collection('ventes_directes').add({
              'serveur': widget.nomServeur,
              'client': cmd['client'],
              'table': cmd['table'],
              'total': cmd['total'],
              'date': _obtenirDateExacte(),
              'timestamp': FieldValue.serverTimestamp()
            });
          }),
      HistoriquePage(ventes: historiqueVentes),
      MonServicePage(
          nomServeur: widget.nomServeur,
          totalEncaisse: totalEncaisseSession,
          nbCommandes: commandesTermineesSession,
          dettesEnCours: monnaieEnAttente.length,
          estTermine: finDeServiceSignalee,
          onCloture: () async {
            setState(() {
              finDeServiceSignalee = true;
            });
            await FirebaseFirestore.instance.collection('bilans_caisse').add({
              'serveur': widget.nomServeur,
              'recette_totale': totalEncaisseSession,
              'commandes_servies': commandesTermineesSession,
              'date_cloture': _obtenirDateExacte(),
              'timestamp_internet': FieldValue.serverTimestamp()
            });
            await FirebaseAuth.instance.signOut();
          })
    ];
    return Scaffold(
        appBar: AppBar(
            title: Row(mainAxisSize: MainAxisSize.min, children: [
              Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                      color: const Color(0xFFF59E0B),
                      borderRadius: BorderRadius.circular(8)),
                  child:
                      const Icon(Icons.person, color: Colors.black, size: 18)),
              const SizedBox(width: 10),
              Text(widget.nomServeur,
                  style: const TextStyle(fontWeight: FontWeight.w800))
            ]),
            backgroundColor: const Color(0xFF111827),
            centerTitle: true,
            elevation: 0,
            actions: [
              IconButton(
                  icon: const Icon(Icons.logout, color: Color(0xFFEF4444)),
                  onPressed: () async {
                    await FirebaseAuth.instance.signOut();
                    if (context.mounted)
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const PageDeConnexion()));
                  })
            ]),
        body: pages[_selectedIndex],
        bottomNavigationBar: BottomNavigationBar(
            currentIndex: _selectedIndex,
            onTap: (index) => setState(() => _selectedIndex = index),
            selectedItemColor: const Color(0xFFF59E0B),
            unselectedItemColor: const Color(0xFF6B7280),
            backgroundColor: const Color(0xFF111827),
            type: BottomNavigationBarType.fixed,
            selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
            items: const [
              BottomNavigationBarItem(
                  icon: Icon(Icons.notifications_active), label: 'En cours'),
              BottomNavigationBarItem(
                  icon: Icon(Icons.point_of_sale), label: 'Caisse'),
              BottomNavigationBarItem(
                  icon: Icon(Icons.history), label: 'Historique'),
              BottomNavigationBarItem(icon: Icon(Icons.badge), label: 'Service')
            ]));
  }
}

class CommandesEnCoursPage extends StatelessWidget {
  final Function(Map<String, dynamic>) onAccept;
  final bool disabled;
  final String nomServeur;
  const CommandesEnCoursPage(
      {required this.onAccept,
      required this.disabled,
      required this.nomServeur,
      super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: disabled
            ? Center(
                child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                        color: const Color(0x1AEF4444),
                        borderRadius: BorderRadius.circular(12)),
                    child: const Text(
                        "SERVICE CLÔTURÉ.\nRelancez l'app pour reprendre.",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Color(0xFFEF4444),
                            fontWeight: FontWeight.bold))))
            : StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('commandes_clients')
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting)
                    return const Center(
                        child: CircularProgressIndicator(
                            color: Color(0xFFF59E0B)));
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty)
                    return const Center(
                        child: Text(
                            "Aucune commande du site web pour le moment...",
                            style: TextStyle(color: Colors.grey)));
                  final commandesFirebase = snapshot.data!.docs;
                  return ListView.builder(
                      padding: const EdgeInsets.all(20),
                      itemCount: commandesFirebase.length,
                      itemBuilder: (context, index) {
                        final doc = commandesFirebase[index];
                        final cmd = {
                          "id": doc.id,
                          "table": doc['table'] ?? "Table ?",
                          "client": doc['client'] ?? "Client",
                          "total": doc['total'] ?? 0,
                          "articles": List<String>.from(doc['articles'] ?? []),
                          "date_creation": doc['date_creation'] ?? "",
                        };
                        return Card(
                            color: const Color(0xFF111827),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)),
                            margin: const EdgeInsets.only(bottom: 15),
                            child: Padding(
                                padding: const EdgeInsets.all(18),
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text("${cmd['table']}",
                                                style: const TextStyle(
                                                    fontWeight: FontWeight.w900,
                                                    fontSize: 18,
                                                    color: Colors.white)),
                                            const Text("Nouveau !",
                                                style: TextStyle(
                                                    color: Color(0xFF10B981),
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 12))
                                          ]),
                                      const Divider(height: 25),
                                      Text("Client : ${cmd['client']}",
                                          style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 16,
                                              color: Color(0xFFF59E0B))),
                                      const SizedBox(height: 10),
                                      Text(
                                          (cmd['articles'] as List<String>)
                                              .join(" • "),
                                          style: const TextStyle(
                                              color: Colors.white70)),
                                      const SizedBox(height: 15),
                                      Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text("${cmd['total']} F",
                                                style: const TextStyle(
                                                    fontWeight: FontWeight.w900,
                                                    fontSize: 20,
                                                    color: Color(0xFF10B981))),
                                            ElevatedButton.icon(
                                                style: ElevatedButton.styleFrom(
                                                    backgroundColor:
                                                        const Color(
                                                            0xFF10B981)),
                                                icon: const Icon(Icons.check,
                                                    size: 18),
                                                onPressed: () async {
                                                  cmd['serveur'] = nomServeur;
                                                  onAccept(cmd);
                                                  await FirebaseFirestore
                                                      .instance
                                                      .collection(
                                                          'commandes_clients')
                                                      .doc(doc.id)
                                                      .delete();
                                                },
                                                label: const Text("ACCEPTER"))
                                          ])
                                    ])));
                      });
                }));
  }
}

class CaisseIntelligentePage extends StatefulWidget {
  final List<Map<String, dynamic>> commandesPayer;
  final List<Map<String, dynamic>> commandesMonnaie;
  final Function(Map<String, dynamic>) onComplete;
  final Function(Map<String, dynamic>) onAttenteMonnaie;
  final Function(Map<String, dynamic>) onRendreMonnaie;
  final bool disabled;
  final String nomServeur;
  const CaisseIntelligentePage(
      {required this.commandesPayer,
      required this.commandesMonnaie,
      required this.onComplete,
      required this.onAttenteMonnaie,
      required this.onRendreMonnaie,
      required this.disabled,
      required this.nomServeur,
      super.key});
  @override
  State<CaisseIntelligentePage> createState() => _CaisseIntelligentePageState();
}

class _CaisseIntelligentePageState extends State<CaisseIntelligentePage> {
  final Map<String, TextEditingController> _controllers = {};
  int _calculerMonnaie(int total, String recuStr) {
    if (recuStr.isEmpty) return 0;
    int recu = int.tryParse(recuStr) ?? 0;
    return recu - total;
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 2,
        child: Scaffold(
            appBar: AppBar(
                backgroundColor: const Color(0xFF0B1120),
                elevation: 0,
                bottom: TabBar(
                    indicatorColor: const Color(0xFFF59E0B),
                    labelColor: const Color(0xFFF59E0B),
                    unselectedLabelColor: const Color(0xFF6B7280),
                    tabs: [
                      Tab(
                          text:
                              "À ENCAISSER (${widget.commandesPayer.length})"),
                      Tab(text: "DETTES (${widget.commandesMonnaie.length})")
                    ]),
                title: null),
            body: widget.disabled
                ? const Center(child: Text("Service clôturé."))
                : TabBarView(children: [
                    _buildOngletPaiement(),
                    _buildOngletMonnaie()
                  ])));
  }

  Widget _buildOngletPaiement() {
    if (widget.commandesPayer.isEmpty)
      return const Center(
          child: Text("Aucune commande en préparation à la caisse."));
    return ListView.builder(
        padding: const EdgeInsets.all(15),
        itemCount: widget.commandesPayer.length,
        itemBuilder: (context, index) {
          final cmd = widget.commandesPayer[index];
          if (!_controllers.containsKey(cmd['id']))
            _controllers[cmd['id']] = TextEditingController();
          int monnaieCalcul =
              _calculerMonnaie(cmd['total'], _controllers[cmd['id']]!.text);
          return Card(
              color: const Color(0xFF111827),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              margin: const EdgeInsets.only(bottom: 15),
              child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("${cmd['table']} — ${cmd['client']}",
                            style: const TextStyle(
                                color: Color(0xFFF59E0B),
                                fontWeight: FontWeight.bold,
                                fontSize: 18)),
                        const Divider(height: 20),
                        Text("TOTAL : ${cmd['total']} F",
                            style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                                color: Colors.white)),
                        const SizedBox(height: 20),
                        Row(children: [
                          Expanded(
                              child: TextField(
                                  controller: _controllers[cmd['id']],
                                  keyboardType: TextInputType.number,
                                  onChanged: (val) => setState(() {}),
                                  decoration: const InputDecoration(
                                      labelText: "Argent reçu (F)",
                                      filled: true))),
                          const SizedBox(width: 12),
                          Expanded(
                              child: Container(
                                  padding: const EdgeInsets.all(20),
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: monnaieCalcul < 0
                                              ? const Color(0xFFEF4444)
                                              : const Color(0xFF10B981)),
                                      borderRadius: BorderRadius.circular(16)),
                                  child: Text("Rendre: $monnaieCalcul F",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          fontWeight: FontWeight.w900,
                                          color: monnaieCalcul < 0
                                              ? const Color(0xFFEF4444)
                                              : const Color(0xFF10B981),
                                          fontSize: 16))))
                        ]),
                        const SizedBox(height: 20),
                        Row(children: [
                          Expanded(
                              child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0x33EF4444),
                                      side: const BorderSide(
                                          color: Color(0xFFEF4444))),
                                  onPressed: () {
                                    cmd['argent_recu'] =
                                        _controllers[cmd['id']]!.text;
                                    cmd['monnaie_due'] = monnaieCalcul;
                                    widget.onAttenteMonnaie(cmd);
                                  },
                                  child: const Text("DETTE",
                                      style: TextStyle(
                                          color: Color(0xFFEF4444))))),
                          const SizedBox(width: 12),
                          Expanded(
                              child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFF10B981)),
                                  onPressed: () {
                                    cmd['argent_recu'] =
                                        _controllers[cmd['id']]!.text;
                                    cmd['monnaie_due'] = monnaieCalcul;
                                    cmd['statut'] = "Réglé";
                                    widget.onComplete(cmd);
                                  },
                                  child: const Text("TERMINER")))
                        ])
                      ])));
        });
  }

  Widget _buildOngletMonnaie() {
    if (widget.commandesMonnaie.isEmpty)
      return const Center(child: Text("Aucune monnaie client en attente."));
    return ListView.builder(
        padding: const EdgeInsets.all(15),
        itemCount: widget.commandesMonnaie.length,
        itemBuilder: (context, index) {
          final cmd = widget.commandesMonnaie[index];
          return Card(
              color: const Color(0x0DEF4444),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              margin: const EdgeInsets.only(bottom: 15),
              child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Table: ${cmd['table']}",
                            style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: Colors.white)),
                        Text("Client : ${cmd['client']}",
                            style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: Color(0xFFF59E0B))),
                        const Divider(height: 20, color: Color(0xFFEF4444)),
                        Text("MONNAIE À RENDRE : ${cmd['monnaie_due']} F",
                            style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                                color: Colors.white)),
                        const SizedBox(height: 20),
                        SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF10B981)),
                                icon: const Icon(Icons.check),
                                onPressed: () {
                                  cmd['statut'] = "Dette réglée";
                                  widget.onRendreMonnaie(cmd);
                                },
                                label: const Text("MONNAIE RENDUE AU CLIENT")))
                      ])));
        });
  }
}

class HistoriquePage extends StatelessWidget {
  final List<Map<String, dynamic>> ventes;
  const HistoriquePage({required this.ventes, super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: ventes.isEmpty
            ? const Center(child: Text("Aucune vente validée ce jour."))
            : ListView.builder(
                padding: const EdgeInsets.all(15),
                itemCount: ventes.length,
                itemBuilder: (context, index) {
                  final v = ventes[index];
                  return Card(
                      color: const Color(0xFF111827),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                          padding: const EdgeInsets.all(15),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text("${v['table']} — ${v['client']}",
                                          style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                              fontSize: 16)),
                                      Text("${v['total']} F",
                                          style: const TextStyle(
                                              fontWeight: FontWeight.w900,
                                              color: Color(0xFF10B981),
                                              fontSize: 18))
                                    ]),
                                const Divider(height: 20),
                                Text(
                                    "Reçu : ${v['argent_recu']} F | Rendu : ${v['monnaie_due']} F",
                                    style: const TextStyle(
                                        color: Color(0xFF9CA3AF)))
                              ])));
                }));
  }
}

class MonServicePage extends StatelessWidget {
  final String nomServeur;
  final int totalEncaisse;
  final int nbCommandes;
  final int dettesEnCours;
  final bool estTermine;
  final VoidCallback onCloture;
  const MonServicePage(
      {required this.nomServeur,
      required this.totalEncaisse,
      required this.nbCommandes,
      required this.dettesEnCours,
      required this.estTermine,
      required this.onCloture,
      super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Padding(
            padding: const EdgeInsets.all(25),
            child: Column(children: [
              const SizedBox(height: 20),
              Icon(estTermine ? Icons.lock : Icons.radio_button_checked,
                  size: 70,
                  color: estTermine
                      ? const Color(0xFFEF4444)
                      : const Color(0xFF10B981)),
              const SizedBox(height: 10),
              Text(estTermine ? "SERVICE CLOS" : "SERVICE EN COURS",
                  style: TextStyle(
                      color: estTermine
                          ? const Color(0xFFEF4444)
                          : const Color(0xFF10B981),
                      fontWeight: FontWeight.bold,
                      fontSize: 16)),
              const Divider(height: 50),
              Container(
                  padding: const EdgeInsets.all(25),
                  decoration: BoxDecoration(
                      color: const Color(0xFF111827),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFF1F2937))),
                  child: Column(children: [
                    _buildInfoRow("Serveur :", nomServeur, Colors.white),
                    const SizedBox(height: 18),
                    _buildInfoRow(
                        "Commandes validées :", "$nbCommandes", Colors.white),
                    const SizedBox(height: 18),
                    _buildInfoRow("Caisse encaissée :", "$totalEncaisse FCFA",
                        const Color(0xFF10B981))
                  ])),
              const Spacer(),
              if (!estTermine)
                SizedBox(
                    width: double.infinity,
                    height: 65,
                    child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFEF4444)),
                        icon: const Icon(Icons.power_settings_new),
                        onPressed: () {
                          if (dettesEnCours > 0) {
                            ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text(
                                        "Veuillez régler toutes les monnaies clients avant de fermer !"),
                                    backgroundColor: Color(0xFFEF4444)));
                            return;
                          }
                          showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                      backgroundColor: const Color(0xFF111827),
                                      title:
                                          const Text("Clôturer le service ?"),
                                      content: const Text(
                                          "Vos recettes vont être envoyées de façon sécurisée à la direction."),
                                      actions: [
                                        TextButton(
                                            onPressed: () =>
                                                Navigator.pop(context),
                                            child: const Text("Annuler",
                                                style: TextStyle(
                                                    color: Color(0xFF9CA3AF)))),
                                        ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                backgroundColor:
                                                    const Color(0xFFEF4444)),
                                            onPressed: () {
                                              Navigator.pop(context);
                                              onCloture();
                                            },
                                            child: const Text("Confirmer"))
                                      ]));
                        },
                        label: const Text("FERMER MA CAISSE")))
              else
                Container(
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(
                        color: const Color(0xFF1F2937),
                        borderRadius: BorderRadius.circular(10)),
                    child: const Text(
                        "Vos recettes sont sécurisées sur le serveur de la direction.",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Color(0xFF9CA3AF)))),
              const SizedBox(height: 20)
            ])));
  }

  Widget _buildInfoRow(String label, String value, Color valueColor) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label,
          style: const TextStyle(color: Color(0xFF9CA3AF), fontSize: 15)),
      Text(value,
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 16, color: valueColor))
    ]);
  }
}
