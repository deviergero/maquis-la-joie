package com.example.app_gerant

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
